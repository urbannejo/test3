/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package parcialn3_urban;

/**
 *
 * @author nejo
 */
public class ParcialN3_Urban {

    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                FrmPrincipal frmPrincipal = new FrmPrincipal();

                frmPrincipal.setVisible(true);
            }
        });
    }
    
}

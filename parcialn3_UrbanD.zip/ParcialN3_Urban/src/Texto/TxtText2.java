/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Texto;

import java.awt.Font;

/**
 *
 * @author nejo
 */
public class TxtText2 extends TxtText1{
    public TxtText2() {
        setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        setFont(new Font("MS Reference Sans Serif", Font.BOLD, 12));
    }
}
